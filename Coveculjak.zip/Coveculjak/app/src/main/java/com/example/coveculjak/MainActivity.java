package com.example.coveculjak;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextHead, editTextBody;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextHead = findViewById(R.id.editTextHead);
        editTextBody = findViewById(R.id.editTextBody);
        imageView = findViewById(R.id.imageView);
        Button buttonDraw = findViewById(R.id.buttonDraw);

        buttonDraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawPerson();
            }
        });
    }

    private void drawPerson() {
        // Uzmi dimenzije glave i trupa
        String headText = editTextHead.getText().toString();
        String bodyText = editTextBody.getText().toString();

        // Pretvori stringove u float vrednosti
        float headSize = Float.parseFloat(headText);
        float bodySize = Float.parseFloat(bodyText);

        // Kreiraj novu sliku i Canvas objekat
        Bitmap bitmap = Bitmap.createBitmap(500, 500, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

        // Postavi Canvas na ImageView
        imageView.setImageBitmap(bitmap);

        // Kreiraj Paint objekte za crtanje
        Paint headPaint = new Paint();
        headPaint.setColor(Color.BLUE);
        headPaint.setStyle(Paint.Style.FILL);

        Paint bodyPaint = new Paint();
        bodyPaint.setColor(Color.GREEN);
        bodyPaint.setStyle(Paint.Style.FILL);

        // Crtaj krug za glavu
        float headX = 250; // x koordinata centra kruga
        float headY = 150; // y koordinata centra kruga
        canvas.drawCircle(headX, headY, headSize, headPaint);

        // Crtaj krug za trup
        float bodyX = 250; // x koordinata centra kruga (ista kao za glavu)
        float bodyY = headY + headSize + bodySize; // y koordinata centra kruga (ispod glave)
        canvas.drawCircle(bodyX, bodyY, bodySize, bodyPaint);
    }

}
