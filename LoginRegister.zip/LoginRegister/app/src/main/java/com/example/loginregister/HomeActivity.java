package com.example.loginregister;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.loginregister.adapter.UserAdapter;
import com.example.loginregister.model.User;
import com.example.loginregister.retrofit.RetrofitService;
import com.example.loginregister.retrofit.UserApi;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import android.os.Bundle;

public class HomeActivity extends AppCompatActivity {
    private RecyclerView recyclerViewUsers;
    private UserAdapter userAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        userAdapter = new UserAdapter(new ArrayList<User>());
        recyclerViewUsers = findViewById(R.id.recyclerViewUsers);
        //recyclerViewUsers.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));\
        recyclerViewUsers.setLayoutManager(new LinearLayoutManager(this));

        //recyclerViewUsers.setLayoutManager(new GridLayoutManager(this, 5)); // Broj kolona možete prilagoditi

        recyclerViewUsers.setAdapter(userAdapter);

        RetrofitService retrofitService = new RetrofitService();
        UserApi userApi = retrofitService.getUserApi();

        Call<List<User>> call = userApi.getAllUsers();
        call.enqueue(new Callback<List<User>>() {
            @Override
            public void onResponse(Call<List<User>> call, Response<List<User>> response) {
                if (response.isSuccessful()) {
                    List<User> userList = response.body();
                    Log.d("API Response", "UserList size: " + userList.size());
                    userAdapter.updateData(userList);
                    Log.d("UserAdapter", "onResponse: UserList size: " + userList.size());

                } else {
                    Log.e("API Error", "Error: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<List<User>> call, Throwable t) {
                Log.e("Network Error", t.getMessage());
            }
        });
    }

}