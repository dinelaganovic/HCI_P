package com.example.flagsquiz;

public class Database {
    Integer[] flags={
            R.drawable.austrija,
            R.drawable.egipat,
            R.drawable.etiopija,
            R.drawable.hrvatska,
            R.drawable.nemacka,
            R.drawable.nepal,
            R.drawable.rusija,
            R.drawable.spanija,
            R.drawable.srbija,
            R.drawable.texsas
    };
    String[] answers={
            "austrija",
            "egipat",
            "etiopija",
            "hrvatska",
            "nemacka",
            "nepal",
            "rusija",
            "spanija",
            "srbija",
            "texsas"
    };
}
