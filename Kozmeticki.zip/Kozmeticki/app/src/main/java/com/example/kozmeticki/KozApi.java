package com.example.kozmeticki;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface KozApi {
    @GET("/api/v1/koz/getAll")
    Call<List<Kozmeticki>> getAllKoz();
    @POST("/api/v1/koz/save")
    Call<Kozmeticki>save(@Body Kozmeticki kozmeticki );
}
