package com.example.kozmeticki;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RetrofitAdapter retrofitAdapter;
    private List<Kozmeticki> kozmetickiList;
    private KozApi kozApi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize RetrofitService
        RetrofitService retrofitService = new RetrofitService();
        kozApi = retrofitService.getKozApi();

        // Create a list of Kozmeticki items
        kozmetickiList = new ArrayList<>();

        // Initialize RetrofitAdapter with the list
        retrofitAdapter = new RetrofitAdapter(kozmetickiList);

        // Set the adapter to the RecyclerView
        recyclerView.setAdapter(retrofitAdapter);

        // Load data from the backend using Retrofit
        fetchDataFromBackend();
    }

    private void fetchDataFromBackend() {
        // Make the network request
        Call<List<Kozmeticki>> call = kozApi.getAllKoz();
        call.enqueue(new Callback<List<Kozmeticki>>() {
            @Override
            public void onResponse(Call<List<Kozmeticki>> call, Response<List<Kozmeticki>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    // Update the adapter with the received data
                    List<Kozmeticki> newData = response.body();
                    retrofitAdapter.updateData(newData);
                } else {
                    // Handle unsuccessful response
                    // You can log an error message or show an error to the user
                }
            }

            @Override
            public void onFailure(Call<List<Kozmeticki>> call, Throwable t) {
                // Handle network failure
                // You can log an error message or show an error to the user
            }
        });
    }
}
