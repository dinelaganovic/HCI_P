package com.example.predmetocena.retrofit;

import com.example.predmetocena.model.Predmet;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface PredmetApi {
    @GET("/api/v1/predmet/getAll")
    Call<List<Predmet>> getAllUsers();
    @POST("/api/v1/predmet/save")
    Call<Predmet>save(@Body Predmet user );
}
