package com.example.predmetocena.adapter;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import android.util.Log;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.TextView;

        import androidx.annotation.NonNull;
        import androidx.recyclerview.widget.RecyclerView;

        import com.example.predmetocena.R;
        import com.example.predmetocena.model.Predmet;

        import java.util.List;

public class PredemetAdapter extends RecyclerView.Adapter<PredemetAdapter.ViewHolder> {

    private List<Predmet> predmetList;

    public PredemetAdapter(List<Predmet> predmetList) {
        this.predmetList = predmetList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_predmet, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Predmet predmet = predmetList.get(position);

        holder.textviewUsername.setText(predmet.getName());
        holder.textviewEmail.setText(String.valueOf(predmet.getOcena()));
        Log.d("PredmetAdapter", "onBindViewHolder called for position: " + position);

    }

    @Override
    public int getItemCount() {
        return predmetList.size();
    }

    public void updateData(List<Predmet> newData) {
        predmetList.clear();
        predmetList.addAll(newData);
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textviewUsername;
        TextView textviewEmail;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textviewUsername = itemView.findViewById(R.id.textViewName);
            textviewEmail = itemView.findViewById(R.id.textViewOcena);

        }

    }
}

