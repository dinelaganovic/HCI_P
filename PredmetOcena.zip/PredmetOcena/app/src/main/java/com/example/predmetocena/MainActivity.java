package com.example.predmetocena;
        import androidx.appcompat.app.AppCompatActivity;
        import android.os.Bundle;
        import android.util.Log;
        import java.util.ArrayList;
        import java.util.List;
        import retrofit2.Call;
        import retrofit2.Callback;
        import retrofit2.Response;
        import com.example.predmetocena.model.Predmet;
        import com.example.predmetocena.retrofit.PredmetApi;
        import com.example.predmetocena.retrofit.RetrofitService;
        import com.github.mikephil.charting.charts.BarChart;
        import com.github.mikephil.charting.components.XAxis;
        import com.github.mikephil.charting.data.BarData;
        import com.github.mikephil.charting.data.BarDataSet;
        import com.github.mikephil.charting.data.BarEntry;
        import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

public class MainActivity extends AppCompatActivity {
    private BarChart barChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        barChart = findViewById(R.id.barChart);

        RetrofitService retrofitService = new RetrofitService();
        PredmetApi predmetApi = retrofitService.getPredmetApi();

        Call<List<Predmet>> call = predmetApi.getAllUsers();
        call.enqueue(new Callback<List<Predmet>>() {
            @Override
            public void onResponse(Call<List<Predmet>> call, Response<List<Predmet>> response) {
                if (response.isSuccessful()) {
                    List<Predmet> predmetList = response.body();
                    Log.d("API Response", "PredmetList size: " + predmetList.size());

                    // Kreiranje unosa za grafikon
                    ArrayList<BarEntry> barEntries = new ArrayList<>();
                    ArrayList<String> labels = new ArrayList<>();
                    for (int i = 0; i < predmetList.size(); i++) {
                        barEntries.add(new BarEntry(i, predmetList.get(i).getOcena()));
                        labels.add(predmetList.get(i).getName());
                    }

                    // Kreiranje skupa podataka za stubićni grafikon
                    BarDataSet barDataSet = new BarDataSet(barEntries, "Ocena");

                    // Kreiranje objekta podataka za stubićni grafikon
                    BarData barData = new BarData(barDataSet);

                    // Prilagodavanje izgleda grafikona
                    barChart.getDescription().setEnabled(false);

                    // Postavljanje etiketa na X-osi
                    XAxis xAxis = barChart.getXAxis();
                    xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
                    xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);

                    barChart.setData(barData);
                    barChart.invalidate(); // Osvježi grafikon
                } else {
                    Log.e("API Error", "Error: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<List<Predmet>> call, Throwable t) {
                Log.e("Network Error", t.getMessage());
            }
        });
    }
}
