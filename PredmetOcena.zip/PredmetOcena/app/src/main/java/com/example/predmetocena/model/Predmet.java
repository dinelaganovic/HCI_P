package com.example.predmetocena.model;

public class Predmet {
    private String name;
    private int ocena;

    public Predmet(String name, int ocena) {
        this.name = name;
        this.ocena = ocena;
    }

    public String getName() {
        return name;
    }

    public int getOcena() {
        return ocena;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setOcena(int ocena) {
        this.ocena = ocena;
    }
}
