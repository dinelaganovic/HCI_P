package com.example.oblicii;


import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

public class ShapesView extends View {

    private Paint paint;

    public ShapesView(Context context) {
        super(context);
        init();
    }

    private void init() {
        paint = new Paint();
        paint.setColor(Color.BLUE);
        paint.setStyle(Paint.Style.FILL);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Crtanje kruga
        float circleRadius = 100;
        float circleX = 200;
        float circleY = 200;
        canvas.drawCircle(circleX, circleY, circleRadius, paint);

        // Crtanje kvadrata
        float squareSize = 200;
        float squareX = 500;
        float squareY = 200;
        canvas.drawRect(squareX, squareY, squareX + squareSize, squareY + squareSize, paint);

        // Crtanje trougla
        Path path = new Path();
        float triangleX1 = 800;
        float triangleY1 = 200;
        float triangleX2 = 1000;
        float triangleY2 = 200;
        float triangleX3 = 900;
        float triangleY3 = 50;
        path.moveTo(triangleX1, triangleY1);
        path.lineTo(triangleX2, triangleY2);
        path.lineTo(triangleX3, triangleY3);
        path.lineTo(triangleX1, triangleY1);
        canvas.drawPath(path, paint);
    }
}
