package com.example.pieex;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pieex.adapter.PredmetAdapter;
import com.example.pieex.model.Predmet;
import com.example.pieex.retrofit.PredmetApi;
import com.example.pieex.retrofit.RetrofitService;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private PredmetAdapter predmetAdapter;
    private PieChart pieChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        predmetAdapter = new PredmetAdapter(new ArrayList<>());
        recyclerView.setAdapter(predmetAdapter);
        pieChart = findViewById(R.id.pieChart);
        setupPieChart();

        fetchDataFromApi();
    }

    private void setupPieChart() {
        // Customize the appearance of the pie chart (optional)
        pieChart.setUsePercentValues(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleColor(android.R.color.transparent);
        pieChart.setTransparentCircleRadius(61f);
    }

    private void updatePieChart(List<Predmet> predmetList) {
        List<PieEntry> entries = new ArrayList<>();
        for (Predmet predmet : predmetList) {
            entries.add(new PieEntry(predmet.getOcena(), predmet.getName()));
        }

        PieDataSet dataSet = new PieDataSet(entries, "My Pie Chart");
        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        dataSet.setValueTextSize(12f);

        PieData data = new PieData(dataSet);
        pieChart.setData(data);
        pieChart.invalidate(); // refresh
    }

    private void fetchDataFromApi() {
        RetrofitService retrofitService = new RetrofitService();
        PredmetApi predmetApi = retrofitService.getPredmetApi();

        Call<List<Predmet>> call = predmetApi.getAllPredmets();
        call.enqueue(new Callback<List<Predmet>>() {
            @Override
            public void onResponse(Call<List<Predmet>> call, Response<List<Predmet>> response) {
                if (response.isSuccessful()) {
                    List<Predmet> predmetList = response.body();
                    if (predmetList != null) {
                        predmetAdapter.updateData(predmetList);
                        updatePieChart(predmetList);
                    }
                } else {
                    // Handle error
                    // For example, you can show a toast message
                    Toast.makeText(MainActivity.this, "Failed to fetch data", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Predmet>> call, Throwable t) {
                // Handle failure
                // For example, you can show a toast message
                Toast.makeText(MainActivity.this, "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }


    /**
     * Customize the pie chart
     *
     *  @Override
     *     protected void onCreate(Bundle savedInstanceState) {
     *         super.onCreate(savedInstanceState);
     *         setContentView(R.layout.activity_main);
     *
     *         //PieChart pieChart = findViewById(R.id.pieChart);
     *       //  setupPieChart(pieChart);
     *       //  loadPieChartData(pieChart);
     *     }
     * private void setupPieChart(PieChart pieChart) {
     *         // Customize the appearance of the pie chart (optional)
     *         pieChart.setUsePercentValues(true);
     *         pieChart.getDescription().setEnabled(false);
     *         pieChart.setDrawHoleEnabled(true);
     *         pieChart.setHoleColor(android.R.color.transparent);
     *         pieChart.setTransparentCircleRadius(61f);
     *     }
     *
     *     private void loadPieChartData(PieChart pieChart) {
     *         List<PieEntry> entries = new ArrayList<>();
     *         entries.add(new PieEntry(18.5f, "Category A"));
     *         entries.add(new PieEntry(26.7f, "Category B"));
     *         entries.add(new PieEntry(24.0f, "Category C"));
     *         entries.add(new PieEntry(30.8f, "Category D"));
     *
     *         PieDataSet dataSet = new PieDataSet(entries, "My Pie Chart");
     *         dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
     *         dataSet.setValueTextSize(12f);
     *
     *         PieData data = new PieData(dataSet);
     *         pieChart.setData(data);
     *         pieChart.invalidate(); // refresh
     *     }
     *
     */

}
