package com.example.pieex.adapter;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import com.example.pieex.R;
import com.example.pieex.model.Predmet;

public class PredmetAdapter extends RecyclerView.Adapter<PredmetAdapter.ViewHolder> {

    private List<Predmet> predmetList;

    public PredmetAdapter(List<Predmet> predmetList) {
        this.predmetList = predmetList;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_predmet, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Predmet predmet = predmetList.get(position);

        holder.textviewUsername.setText(predmet.getName());
        holder.textviewEmail.setText(String.valueOf(predmet.getOcena()));
        Log.d("PredmetAdapter", "onBindViewHolder called for position: " + position);
    }

    @Override
    public int getItemCount() {
        return predmetList.size();
    }

    public void updateData(List<Predmet> newPredmetList) {
        predmetList.clear();
        predmetList.addAll(newPredmetList);
        notifyDataSetChanged();
    }

    // ViewHolder should extend RecyclerView.ViewHolder
    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textviewUsername;
        TextView textviewEmail;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textviewUsername = itemView.findViewById(R.id.textViewName);
            textviewEmail = itemView.findViewById(R.id.textViewOcena);
        }
    }
}
