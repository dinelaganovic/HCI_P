package com.example.crtanjekucice.model;

public class Kucica {
    private  int dimension;
    private  String color;
    private  int size;

    public Kucica() {
    }

    public Kucica( int dimension, String color, int size) {
        this.dimension = dimension;
        this.color = color;
        this.size = size;
    }


    public void setDimension(int dimension) {
        this.dimension = dimension;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getDimension() {
        return dimension;
    }

    public String getColor() {
        return color;
    }

    public int getSize() {
        return size;
    }


}
