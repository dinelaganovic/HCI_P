package com.example.crtanjekucice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent intent = getIntent();
        int dimension = intent.getIntExtra("DIMENSION", 0);
        String color = intent.getStringExtra("COLOR");
        int size = intent.getIntExtra("SIZE", 0);

        // Update TextViews or other UI elements with the retrieved data
        TextView textViewDimensionResult = findViewById(R.id.textViewDimensionResult);
        TextView textViewColorResult = findViewById(R.id.textViewColorResult);
        TextView textViewSizeResult = findViewById(R.id.textViewSizeResult);

        textViewDimensionResult.setText("Dimenzija: " + dimension);
        textViewColorResult.setText("Boja: " + color);
        textViewSizeResult.setText("Veličina: " + size);

        // Set up custom view
        HouseView houseView = findViewById(R.id.houseView);
        houseView.setHouseDetails(dimension, color, size);
    }

}