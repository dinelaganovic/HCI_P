package com.example.crtanjekucice.api;

import com.example.crtanjekucice.model.Kucica;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface KucicaApi {
    @POST("/api/v1/kucica/save")
    Call<Kucica> save(@Body Kucica kucica );
}
