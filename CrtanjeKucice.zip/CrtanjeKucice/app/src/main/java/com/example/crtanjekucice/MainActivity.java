package com.example.crtanjekucice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.crtanjekucice.api.KucicaApi;
import com.example.crtanjekucice.model.Kucica;
import com.example.crtanjekucice.retrofit.RetrofitService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {
    private KucicaApi kucicaApi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textViewDimension = findViewById(R.id.textViewDimension);
        TextView textViewColor = findViewById(R.id.textViewColor);
        TextView textViewSize = findViewById(R.id.textViewSize);

        textViewDimension.setText("12");
        textViewColor.setText("red");
        textViewSize.setText("12");
    }
    private void saveKucica(Kucica kucica) {
        Call<Kucica> call = kucicaApi.save(kucica);
        call.enqueue(new Callback<Kucica>() {
            @Override
            public void onResponse(Call<Kucica> call, Response<Kucica> response) {
                if (response.isSuccessful()) {
                    // Handle successful response
                    // You can add additional logic here if needed
                } else {
                    // Handle unsuccessful response
                }
            }

            @Override
            public void onFailure(Call<Kucica> call, Throwable t) {
                // Handle failure
            }
        });
    }
    public void onDrawButtonClick(View view) {
        // Dobijanje vrednosti iz elemenata korisničkog sučelja
        TextView textViewDimension = findViewById(R.id.textViewDimension);
        TextView textViewColor = findViewById(R.id.textViewColor);
        TextView textViewSize = findViewById(R.id.textViewSize);

        String dimension = textViewDimension.getText().toString();
        String color = textViewColor.getText().toString();
        String size = textViewSize.getText().toString();

        // Prenos podataka u drugi Activity
        Intent intent = new Intent(this, SecondActivity.class);
        intent.putExtra("DIMENSION", Integer.parseInt(dimension));
        intent.putExtra("COLOR", color);
        intent.putExtra("SIZE", Integer.parseInt(size)); // Pretvaranje teksta u celobrojnu vrednost
        startActivity(intent);

        //kucica save
        RetrofitService retrofitService = new RetrofitService();
        Retrofit retrofit = retrofitService.getRetrofit();
        kucicaApi = retrofit.create(KucicaApi.class);

        // Create a Kucica object with the retrieved data
        Kucica kucica = new Kucica(Integer.parseInt(dimension), color, Integer.parseInt(size));

        // Call the API to save the Kucica object
        saveKucica(kucica);
    }


}