package com.example.crtanjekucice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textViewDimension = findViewById(R.id.textViewDimension);
        TextView textViewColor = findViewById(R.id.textViewColor);
        TextView textViewSize = findViewById(R.id.textViewSize);

        textViewDimension.setText("12");
        textViewColor.setText("red");
        textViewSize.setText("12");
    }

    public void onDrawButtonClick(View view) {
        // Dobijanje vrednosti iz elemenata korisničkog sučelja
        TextView textViewDimension = findViewById(R.id.textViewDimension);
        TextView textViewColor = findViewById(R.id.textViewColor);
        TextView textViewSize = findViewById(R.id.textViewSize);

        String dimension = textViewDimension.getText().toString();
        String color = textViewColor.getText().toString();
        String size = textViewSize.getText().toString();

        // Prenos podataka u drugi Activity
        Intent intent = new Intent(this, SecondActivity.class);
        intent.putExtra("DIMENSION", Integer.parseInt(dimension));
        intent.putExtra("COLOR", color);
        intent.putExtra("SIZE", Integer.parseInt(size)); // Pretvaranje teksta u celobrojnu vrednost

        startActivity(intent);
    }

}