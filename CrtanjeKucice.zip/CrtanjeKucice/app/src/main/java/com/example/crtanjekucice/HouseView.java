package com.example.crtanjekucice;


import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.graphics.Path;


public class HouseView extends View {

    private int dimension;
    private String color;
    private int size;

    public HouseView(Context context) {
        super(context);
        init();
    }

    public HouseView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public HouseView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
        // Set default values
        dimension = 0;
        color = "";
        size = 0;
    }

    public void setHouseDetails(int dimension, String color, int size) {
        this.dimension = dimension;
        this.color = color;
        this.size = size;
        invalidate(); // Request a redraw
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Drawing logic for the house
        Paint paint = new Paint();
        paint.setColor(Color.parseColor(color));
        paint.setStyle(Paint.Style.FILL);

        // Draw a simple rectangle as the house body
        int houseWidth = dimension * size;
        int houseHeight = dimension * size;
        canvas.drawRect(50, 50, 50 + houseWidth, 50 + houseHeight, paint);

        // Draw a triangle as the roof
        Path roofPath = new Path();
        roofPath.moveTo(50, 50);
        roofPath.lineTo(50 + houseWidth, 50);
        roofPath.lineTo(50 + houseWidth / 2, 50 - (dimension * size / 2));
        roofPath.close();

        canvas.drawPath(roofPath, paint);
    }


}
